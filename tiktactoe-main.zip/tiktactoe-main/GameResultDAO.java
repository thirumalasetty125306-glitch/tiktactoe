import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class GameResultDAO {

    public void saveResult(String playerName, String result) {
        String query = "INSERT INTO game_results (player_name, result) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, playerName);
            stmt.setString(2, result);
            stmt.executeUpdate();
            System.out.println("Result saved successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
