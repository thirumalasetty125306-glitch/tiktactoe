import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TicTacToeGame extends JFrame implements ActionListener {

    private JButton[] buttons = new JButton[9];
    private boolean xTurn = true;
    private GameResultDAO dao = new GameResultDAO();

    public TicTacToeGame() {
        setTitle("Tic Tac Toe");
        setSize(300, 300);
        setLayout(new GridLayout(3, 3));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        for (int i = 0; i < 9; i++) {
            buttons[i] = new JButton("");
            buttons[i].setFont(new Font("Arial", Font.BOLD, 40));
            buttons[i].addActionListener(this);
            add(buttons[i]);
        }

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        JButton buttonClicked = (JButton) e.getSource();

        if (!buttonClicked.getText().equals("")) return; // ignore filled

        buttonClicked.setText(xTurn ? "X" : "O");
        xTurn = !xTurn;

        String winner = checkWinner();
        if (winner != null) {
            JOptionPane.showMessageDialog(this, "Winner: " + winner);
            String name = JOptionPane.showInputDialog("Enter your name:");
            dao.saveResult(name, winner);
            resetBoard();
        } else if (isFull()) {
            JOptionPane.showMessageDialog(this, "It's a draw!");
            String name = JOptionPane.showInputDialog("Enter your name:");
            dao.saveResult(name, "Draw");
            resetBoard();
        }
    }

    private boolean isFull() {
        for (JButton b : buttons)
            if (b.getText().equals("")) return false;
        return true;
    }

    private String checkWinner() {
        String[][] patterns = {
            { "0", "1", "2" }, { "3", "4", "5" }, { "6", "7", "8" },
            { "0", "3", "6" }, { "1", "4", "7" }, { "2", "5", "8" },
            { "0", "4", "8" }, { "2", "4", "6" }
        };

        for (String[] pattern : patterns) {
            String a = buttons[Integer.parseInt(pattern[0])].getText();
            String b = buttons[Integer.parseInt(pattern[1])].getText();
            String c = buttons[Integer.parseInt(pattern[2])].getText();

            if (!a.equals("") && a.equals(b) && b.equals(c))
                return a; // X or O
        }
        return null;
    }

    private void resetBoard() {
        for (JButton b : buttons) b.setText("");
        xTurn = true;
    }

    public static void main(String[] args) {
        new TicTacToeGame();
    }
}
